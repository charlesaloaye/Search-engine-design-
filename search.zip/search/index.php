
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Search For Stuffs</title>
<meta name="description" content="Search Stuffs is an open source search engine template by sedenu charles">
	<meta name="keywords" content="Search,Find,Show me,reveal,what is,how to">
<meta name="author" content="charles">
<link href="css/bootstrap.min.css" type="text/css" rel="stylesheet">

   <link rel="stylesheet" type="text/css" href="css/search.css">
<!-- Custom fonts for this template -->
<link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
</head>


<body>
<div class="container">
<header class="page-header" role="header">
<h1>
<a href="search.php">
<font color="#fff">
SFS
</font>
</a>
</h1>
</header>
<div class="row">
<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xlg-12">
<!--form started here-->
<br><br><br><br><br><br><br><br><br><br>
<form class="form-horizontal" role="form" method="Get" action=""
name="reveal">
<div class="input-group">
<input type="text"  name="search_field" placeholder="What are you looking for ?" class="form-control" id="s_field">
<span class="input-group-btn">
<button type="submit" name"search" class="btn btn-primary"><i class="fa fa-search"></i>
</span>
</div>

</form> <!--form ends here-->

</div>
</div>
<br>
</div>
<br>
<div class="container">

<footer class="fixed-bottom text-right"> &copy; 2017 Search For Stuffs

</footer>
</div>
</body>
</html>